from setuptools import setup, find_packages

setup(
    name='mypackage',
    version=0.1,
    description='test for class',
    install_required =['numpy']
)